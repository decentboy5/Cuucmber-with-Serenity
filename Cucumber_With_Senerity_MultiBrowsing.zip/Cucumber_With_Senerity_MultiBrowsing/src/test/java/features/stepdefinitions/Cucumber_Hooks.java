package features.stepdefinitions;

import org.apache.log4j.Logger;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import eZLM.Automation.accelerators.Browser;
import eZLM.Automation.accelerators.Report;
import eZLM.Automation.utilities.ConfiguratorFileSupport;


public class Cucumber_Hooks {

	public static String Scenario_Name;
	public Logger Log = Logger.getLogger(Cucumber_Hooks.class);
	public static ConfiguratorFileSupport configProps = new ConfiguratorFileSupport(
			System.getProperty("user.dir") + "//" + "TLMConfiguration.properties");
	@Before
	public void BeforeScenario(Scenario scenario) {
		
		Report.Scenario_name = scenario.getName();

		Log.info(
				"------------------------------------Scenario Started---------------------------------------------------------------------------");
		Log.info("Scenario : " + scenario.getName() + " Started ");

	}

	@After
	public void AfterScenario(Scenario scenario) {

		Log.info("Scenario : " + scenario.getName() + " Ended ");
		Log.info(
				"---------------------------------------Scenario Ended------------------------------------------------------------------------");

		
		Browser.SleepTime++;

	}

}
