package features;

import cucumber.api.CucumberOptions;
import cucumber.api.java.Before;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.thucydides.core.annotations.Step;

import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features="src/test/resources/features/GoogleLogin/")
public class LoginPageRunner {
	
	@Step
	@org.junit.Before
	public void gg()
	{
		System.out.println("gggggggggggggggggg");
	}

}
