package eZLM.Automation.accelerators;

import java.io.File;
import java.io.IOException;
import java.util.Properties;



import org.apache.commons.io.FileDeleteStrategy;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;

import eZLM.Automation.utilities.ConfiguratorFileSupport;

public class Report {
	public static String ScreenShot_Path_Name=null;
	public static Logger Log = Logger.getLogger(Report.class);
	public static ConfiguratorFileSupport configProps = new ConfiguratorFileSupport(
			System.getProperty("user.dir") + "//" + "TLMConfiguration.properties");

	public static void main(String[] args) throws IOException {
		
	}

	public static String Scenario_name;

	public static void failure(String locatorName, WebDriver driver, String ErrorMessage) {

		String Scenario_name_Converted, locatorName_Converted;

		// modifying Scenario_name and Locator Name to Make it as Single String
		Scenario_name_Converted = make_it_as_SingleVariable(Scenario_name);
		System.out.println("");
		locatorName_Converted = make_it_as_SingleVariable(locatorName);

		String fileName = ScreenshotFilePath() + File.separatorChar + Scenario_name_Converted + "AND_"
				+ locatorName_Converted + ".jpeg";
		Screenshot(fileName, driver);		
		Assert.fail(locatorName+ "   "+ErrorMessage);

	}

	private static void Screenshot(String fileName, WebDriver driver) {
		WebDriver driverScreenShot = new Augmenter().augment(driver);
		File scrFile = ((TakesScreenshot) driverScreenShot).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File(fileName));
			Log.info("ScreenShot is available  at :" + fileName);
			ScreenShot_Path_Name=fileName;
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static String make_it_as_SingleVariable(String Name_Conversion) {
		Name_Conversion = Name_Conversion.replaceAll(":", "_");
		Name_Conversion = Name_Conversion.replaceAll(",", "_");
		Name_Conversion = Name_Conversion.replaceAll("&", "_");
		Name_Conversion = Name_Conversion.replaceAll(" ", "_");
		return Name_Conversion;
	}

	public static void getScenarioName(String Scenario) {

	}

	private static String ScreenshotFilePath() {

		String ScreenShot_Directory = "ScreenShots";

		File resultDir = new File(
				ConfiguratorFileSupport.getProperty("Screenshots_Path") + File.separator + ScreenShot_Directory);

		if (resultDir.exists() == false) {
			try {
				resultDir.mkdirs();
			} catch (Exception e) {

			}
		}
		ScreenShot_Directory = ConfiguratorFileSupport.getProperty("Screenshots_Path") + File.separator
				+ ScreenShot_Directory;
		return ScreenShot_Directory;

	}

	/**
	 * Its Custom Method which is used to Cleanup the Screenshots folder and
	 * Logs Folder
	 */
	public static void cleanup() {

		File resultDir=null;
		// Clean up Screenshots folder
		try {

			String ScreenShot_Directory = "ScreenShots";

			resultDir = new File(
					ConfiguratorFileSupport.getProperty("Screenshots_Path") + File.separator + ScreenShot_Directory);

			if (resultDir.exists() == false) {
				try {
					resultDir.mkdirs();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			FileUtils.cleanDirectory(resultDir);
			for (File file : resultDir.listFiles()) {
			    FileDeleteStrategy.FORCE.delete(file);
			}   
		} catch (IOException e) {
			for (File file : resultDir.listFiles()) {
			    try {
					FileDeleteStrategy.FORCE.delete(file);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}  
			e.printStackTrace();
		}

		// Clean up Log Files
		String Log_folder = "Logs";

		resultDir = new File(System.getProperty("user.dir") + File.separator + Log_folder);
		try {
			FileUtils.cleanDirectory(resultDir);
		} catch (Exception e) {

		}

	}

	
	}
