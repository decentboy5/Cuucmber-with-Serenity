package eZLM.Automation.utilities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * CSVDataReader :: It reads the data from CSV file and puts the data in to a
 * map as key-value pairs.
 * 
 * 
 */
public class CSVDataReader {

	private static BufferedReader bufferedReader;

	/**
	 * loadTestData :: It loads the test data from CSV file based on testCaseID.
	 */
	
	public static List<HashMap<String, String>> ReadDatafromCSV(String CSV_FileName) {
		List<HashMap<String, String>> testdata = null;
		try {
			testdata = loadTestData(CSV_FileName, "");			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testdata;
	}

	/**
	 * loadTestData :: It loads the test data from CSV file based on testCaseID
	 * and appName.
	 */
	public static List<HashMap<String, String>> loadTestData(String CSV_FileName, String appName) {
		List<HashMap<String, String>> testdata = new ArrayList<HashMap<String, String>>();
		try {
			System.out.println("     ");
			String splitBy = ",";
			String testdata_subFolder=null;
			String testdata_FileName=null;
			String testDataFileName;
			if(CSV_FileName.contains("\\"))
					{
				testdata_subFolder=CSV_FileName.split("\\\\")[0];
				testdata_FileName=CSV_FileName.split("\\\\")[1];
				testDataFileName = ConfiguratorFileSupport.getProperty("TestData_Path")+"\\"+testdata_subFolder+"\\"+testdata_FileName+".csv";
					}
			else
			{
				testDataFileName = ConfiguratorFileSupport.getProperty("TestData_Path")+"\\"+CSV_FileName + ".csv";
			}
			
			//String testDataFileName = System.getProperty("user.dir") + "\\" + CSV_FileName + ".csv";
			bufferedReader = new BufferedReader(new FileReader(testDataFileName));
			String line = bufferedReader.readLine();
			boolean firstRecord = true;
			Integer recordCounter = 0;
			String[] headerData = null;
			while (line != null) {
				if (firstRecord) {
					headerData = line.split(splitBy);
					firstRecord = false;
				} else {
					String[] columnData = line.split(splitBy);
					LinkedHashMap<String, String> currentData = new LinkedHashMap<String, String>();
					for (Integer i = 0; i < headerData.length; i++) {
						// currentData.put(headerData[i],
						// columnData[i].replaceAll("&COMMA", ","));
						currentData.put(headerData[i], columnData[i]);
					}
					testdata.add(recordCounter, currentData);
					recordCounter = recordCounter + 1;
				}
				line = bufferedReader.readLine();
			}
		} catch (Exception exp) {
			testdata = null;
		}
		return testdata;
	}

	/**
	 * loadTestDataByKey :: It loads the test data from CSV file based on
	 * testCaseID and key.
	 */
	public HashMap<String, String> loadTestDataByKey(String CSV_FileName, String key) {
		HashMap<String, String> testdata = new HashMap<String, String>();
		try {
			String splitBy = ",";
			String testDataFileName = System.getProperty("user.dir") + "\\" + CSV_FileName + ".csv";
			// String testDataFileName = System.getProperty("user.dir") +
			// "/Data/"+ Configuration.GetProperty("CurrentApplication") + "\\"
			// + testCaseID + ".csv";
			bufferedReader = new BufferedReader(new FileReader(testDataFileName));
			String line = bufferedReader.readLine();
			boolean firstRecord = true;
			Integer recordCounter = 0;
			String[] headerData = null;
			while (line != null) {
				if (firstRecord) {
					headerData = line.split(splitBy);
					firstRecord = false;
				} else {
					String[] columnData = line.split(splitBy);

					for (Integer i = 0; i < headerData.length; i++) {
						if (headerData[i].equals(key)) {
							// testdata.put(headerData[i],
							// columnData[i].replaceAll("&COMMA", ","));
							testdata.put(headerData[i], columnData[i]);

							break;
						}
					}
					recordCounter = recordCounter + 1;
				}
				line = bufferedReader.readLine();
			}
		} catch (Exception exp) {
			testdata = null;
		}
		return testdata;
	}

	/**
	 * loadTestDataForObject :: It loads the test data from CSV file based on
	 * testCaseID and key.
	 */
	public HashMap<String, String> loadTestDataForObject(String testCaseID, String key) {
		HashMap<String, String> testdata = new HashMap<String, String>();
		try {
			String splitBy = ",";
			String testDataFileName = null;
			if (testCaseID.toLowerCase().equals("login"))
				testDataFileName = System.getProperty("user.dir") + "/Data/" + "Objects\\" + testCaseID + ".csv";
			else
				testDataFileName = System.getProperty("user.dir") + "/Data/" + "Objects\\" + "\\" + testCaseID + ".csv";
			bufferedReader = new BufferedReader(new FileReader(testDataFileName));
			String line = bufferedReader.readLine();
			boolean firstRecord = true;
			Integer recordCounter = 0;
			String[] headerData = null;
			while (line != null) {
				if (firstRecord) {
					headerData = line.split(splitBy);
					firstRecord = false;
				} else {
					String[] columnData = line.split(splitBy);
					for (Integer i = 0; i < headerData.length; i++) {
						testdata.put(headerData[i], columnData[i].replaceAll("&COMMA", ","));
					}
					if (testdata.get("Key").equals(key))
						break;
					recordCounter = recordCounter + 1;
				}
				line = bufferedReader.readLine();
			}
		} catch (Exception exp) {
			testdata = null;
		}
		return testdata;
	}
	

}
