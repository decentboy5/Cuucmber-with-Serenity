package features.stepdefinitions;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Step;

public class XStepDefinitions {
	
	
	public static WebDriver driver;

	@Step
	@Test
	@When("^login to the application$")
	public void login_to_the_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		/*System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		driver=new ChromeDriver();		
		driver.get("https://www.google.com");*/
	}

	@Step
	@Test
	@When("^Search the Keyword Hello$")
	public void search_the_Keyword_Hello() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

	   //driver.findElement(By.name("q")).sendKeys("Helloo");
	}

	@Step
	@Test
	@Then("^again login into google$")
	public void again_login_into_google() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("");
	    //driver.navigate().to("https://www.google.com");
	}


}
